import '../css/main.css';
import '../css/pages/home.css';
